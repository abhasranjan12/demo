from django.db import models
from phonenumber_field.modelfields import PhoneNumberField

# from FormsApp import forms

Gend = (
    ('male', "MALE"),
    ('female', "FEMALE")
)


# Create your models here.
class form_external_database(models.Model):
    cand_name = models.CharField(max_length=30, blank=False)
    cand_gend = models.CharField(max_length=7, choices=Gend, default='MALE', blank=False)
    pers_emaiId = models.EmailField(max_length=30, blank=False, unique=True)
    cand_contact_no = PhoneNumberField(blank=False, unique=True)
    Tot_exp = models.IntegerField(blank=False)
    Relevant_exp = models.IntegerField(blank=False)
    Skill_set = models.CharField(max_length=100, blank=False)
    Currrent_CTC = models.IntegerField(blank=False)
    Notice_period = models.IntegerField(blank=False)
    Offered_CTC = models.IntegerField(blank=False)
    DOJ = models.DateField(blank=False)









