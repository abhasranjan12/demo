from django.contrib import admin
from .models import form_external_database
# Register your models here.
admin.site.register(form_external_database)