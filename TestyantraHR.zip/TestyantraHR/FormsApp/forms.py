from django.forms import ModelForm
from FormsApp.models import form_external_database


class ExteEmployeeForm(ModelForm):
    class Meta:
        model = form_external_database
        fields = '__all__'