from django.conf.urls import url
from .views import candidate_details
urlpatterns = [
    # url(r'^$', candidate_details),
    url(r'^name', candidate_details),
]

