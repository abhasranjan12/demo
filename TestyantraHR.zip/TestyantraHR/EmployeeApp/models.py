from django.db import models
from phonenumber_field.modelfields import PhoneNumberField

Gend = (
    ('male', "MALE"),
    ('female', "FEMALE")
)
Blood_grp = (
    ('A+', "A+"),
    ('B+', "B+"),
    ('O+', "O+"),
    ('AB+', "AB+"),
    ('A-', "A-"),
    ('B-', "B-"),
    ('O-', "O-"),
    ('AB-', "AB-"),
)
Marital_stat = (
    ('married', "MARRIED"),
    ('unmarried', "UNMARRIED"),
    ('Divorced', "DIVORCED"),
)
YOP = (
    ('2020', "2020"),
    ('2019', "2019"),
    ('2018', "2018"),
    ('2017', "2017"),
    ('2016', "2016"),
    ('2015', "2015"),
    ('2014', "2014"),
    ('2013', "2013"),
    ('2012', "2012"),
    ('2011', "2011"),
    ('2010', "2010"),
    ('2009', "2009"),
    ('2008', "2008"),
    ('2007', "2007"),
    ('2006', "2006"),
    ('2005', "2005"),
    ('2004', "2004"),
    ('2003', "2003"),
    ('2002', "2002"),
    ('2001', "2001"),
    ('2000', '2000'),
    ('1999', "1999"),
    ('1998', "1998"),
    ('1997', "1997"),

)
stat = (
    ('Bench', "BENCH"),
    ('External', "EXTERNAL"),
    ('Internal', "INTERNAL"),
)


# Create your models here.
class Form_Cand_Database(models.Model):
    Employee_ID = models.CharField(max_length=30, blank=False)
    cand_name = models.CharField(max_length=30, blank=False)
    Father_name = models.CharField(max_length=30, blank=False)
    Mother_name = models.CharField(max_length=30, blank=False)
    Blood_Group = models.CharField(max_length=4, choices=Blood_grp, default=None, blank=False)
    DOB = models.DateField(blank=False)
    Sex = models.CharField(max_length=7, choices=Gend, default='MALE', blank=False)
    Marital_status = models.CharField(max_length=30, choices=Marital_stat, default='MARRIED', blank=False)
    Spouse_name = models.CharField(max_length=30)
    Designation = models.CharField(max_length=30, blank=False)
    Permanent_Address = models.CharField(max_length=200, blank=False)
    Present_Address = models.CharField(max_length=200, blank=False)
    pers_emaiId = models.EmailField(max_length=30, blank=False, unique=True)
    contact_no = PhoneNumberField(blank=False, unique=True)
    Post_graduation = models.CharField(max_length=20, blank=False)
    pg_university = models.CharField(max_length=200, blank=False)
    Pg_yop = models.DateField(max_length=4, choices=YOP, default="2020", blank=False)
    graduation = models.CharField(max_length=20, blank=False)
    graduation_university = models.CharField(max_length=200, blank=False)
    graduation_yop = models.DateField(max_length=4, choices=YOP, default="2020", blank=False)
    puc = models.CharField(max_length=20, blank=False)
    puc_board = models.CharField(max_length=200, blank=False)
    puc_yop = models.DateField(max_length=4, choices=YOP, default="2020", blank=False)
    Tenth = models.CharField(max_length=20, blank=False)
    Tenth_board = models.CharField(max_length=200, blank=False)
    Tenth_yop = models.DateField(max_length=4, choices=YOP, default="2020", blank=False)
    Employer1 = models.CharField(max_length=20)
    Emp1_designation = models.CharField(max_length=20)
    emp1_from_date = models.DateField()
    emp1_to_date = models.DateField()
    Employer2 = models.CharField(max_length=20)
    Emp2_designation = models.CharField(max_length=20)
    emp2_from_date = models.DateField()
    emp2_to_date = models.DateField()
    date_of_joining = models.DateField()
    PAN = models.CharField(max_length=15)
    UAN = models.CharField(max_length=50)
    PF_number = models.CharField(max_length=50)
    Aadhar_no = models.IntegerField()
    bank_acc_no = models.IntegerField()
    bank_Name = models.CharField(max_length=40)
    IFSC_code = models.CharField(max_length=20)
    bank_branch = models.CharField(max_length=40)
    status = models.CharField(max_length=40, choices=stat, default='BENCH', blank=False)
