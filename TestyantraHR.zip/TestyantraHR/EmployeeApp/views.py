from django.http import HttpResponseRedirect
from django.shortcuts import render
from . import Emp_forms


# Create your views here.
def Employee_details(request):
    form = Emp_forms.EmployeeForm
    if request.method == 'POST':
        form = Emp_forms.EmployeeForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            form = Emp_forms.EmployeeForm()
            return HttpResponseRedirect('')

    return render(request, "name.html", {'form': form})


