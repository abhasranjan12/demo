from django.contrib import admin
from .models import Form_Cand_Database
# Register your models here.
admin.site.register(Form_Cand_Database)
