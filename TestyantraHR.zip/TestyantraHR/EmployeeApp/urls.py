from django.conf.urls import url
from .views import Employee_details
from .clientAPI import ClientViewAPI
app_name = 'EmployeeApp'

urlpatterns = [
    # url(r'^$', candidate_details),
    url(r'candidateform', Employee_details),
    # url(r'clientportal', Client_details),
]