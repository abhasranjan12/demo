from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from .client_serializers import Clientserializer
from .models import Form_Cand_Database


class ClientViewAPI(APIView):
    def get(self, request):
        cand_db = Form_Cand_Database.objects.all()
        serializers_class = Clientserializer(cand_db, many=True)
        return Response(serializers_class.data)

