from rest_framework import serializers
from .models import Form_Cand_Database


class Clientserializer(serializers.ModelSerializer):
    class Meta:
        model = Form_Cand_Database
        fields = ('Employee_ID', 'cand_name', 'Father_name', 'Mother_name', 'Blood_Group', 'DOB', 'Sex', 'Designation', 'Permanent_Address', 'Present_Address','pers_emaiId', 'contact_no', 'date_of_joining', 'PAN')
