from django.forms import ModelForm
from EmployeeApp.models import Form_Cand_Database

class EmployeeForm(ModelForm):
    class Meta:
        model = Form_Cand_Database
        fields = '__all__'