from django.forms import ModelForm
from EmployeeApp.models import Form_Cand_Database

class ClientPortal(ModelForm):
    class Meta:
        model = Form_Cand_Database
        fields = ('Employee_ID', 'cand_name', 'Father_name', 'Mother_name', 'Blood_Group', 'DOB', 'Sex', 'Designation', 'Permanent_Address', 'Present_Address','pers_emaiId', 'contact_no', 'date_of_joining', 'PAN', 'status')