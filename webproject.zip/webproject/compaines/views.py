from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Stock
from .serializers import Stockserializer
from rest_framework.permissions import IsAuthenticated


# Create your views here.


class StockList(APIView):
    def get(self, request):
        stocks = Stock.objects.all()
        serializers = Stockserializer(stocks, many=True)
        return Response(serializers.data)

    def post(self):
        pass
