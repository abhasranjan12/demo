from django.apps import AppConfig


class CompainesConfig(AppConfig):
    name = 'compaines'
